import os
import json
import base64
import io
import math
from flask import Flask, render_template, request, jsonify
from PIL import Image, ImageDraw, ImageColor, ImageFont
from google import genai
from google.genai.types import (
    GenerateContentConfig,
    HarmBlockThreshold,
    HarmCategory,
    HttpOptions,
    Part,
    SafetySetting,
)
from dotenv import load_dotenv
from typing import List
from pydantic import BaseModel

load_dotenv()

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Initialize the client with the new SDK
client = genai.Client(api_key=os.getenv('GEMINI_API_KEY'))


# Helper class to represent a bounding box
class BoundingBox(BaseModel):
    """
    Represents a bounding box with its 2D coordinates and associated label.

    Attributes:
        box_2d (list[int]): A list of integers representing the 2D coordinates of the bounding box,
                            typically in the format [y_min, x_min, y_max, x_max].
        label (str): A string representing the label or class associated with the object within the bounding box.
    """
    box_2d: List[int]
    label: str


# Predefined system prompts
SYSTEM_PROMPTS = {
    "Gemini-2.0-BEST": """Return bounding boxes for icons, svgs, clickable elements, buttons, etc as an array with labels.
Never return masks. Limit to 25 objects.
If an object is present multiple times, give each object a unique label
according to its distinct characteristics (action, colors, size, position, etc..).
Exclude anything that is grayed out.""",
    
    "Gemini-2.5-BEST": """Return bounding boxes as an array with labels.
Never return masks.
If an object is present multiple times, give each object a unique label
according to its distinct characteristics (action, colors, size, position, etc..).

IGNORE ANYTHING NOT IN FOCUS"""
}

DEFAULT_SYSTEM_PROMPT = SYSTEM_PROMPTS["Gemini-2.0-BEST"]

# Better colors for bounding boxes (bright, distinct colors)
BBOX_COLORS = [
    '#FF0000',  # Red
    '#00FF00',  # Green
    '#FFFF00',  # Yellow
    '#0000FF',  # Blue
    '#FF00FF',  # Magenta
    '#00FFFF',  # Cyan
    '#FF8000',  # Orange
    '#8000FF',  # Purple
]


def hex_to_rgb(hex_color):
    """Convert hex color to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def calculate_label_bounds(x, y, label_text, font):
    """Calculate the bounding rectangle for a label"""
    if font:
        bbox = font.getbbox(label_text)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
    else:
        text_width = len(label_text) * 8
        text_height = 12

    # Add padding for the circle background
    radius = max(15, max(text_width, text_height) // 2 + 3)
    return {
        'x1': x - radius,
        'y1': y - radius,
        'x2': x + radius,
        'y2': y + radius,
        'radius': radius
    }


def rectangles_overlap(rect1, rect2):
    """Check if two rectangles overlap"""
    return not (rect1['x2'] < rect2['x1'] or rect2['x2'] < rect1['x1']
                or rect1['y2'] < rect2['y1'] or rect2['y2'] < rect1['y1'])


def point_in_rectangle(x, y, rect):
    """Check if a point is inside a rectangle"""
    return rect[0] <= x <= rect[2] and rect[1] <= y <= rect[3]


def line_intersects_rectangle(x1, y1, x2, y2, rect_x1, rect_y1, rect_x2,
                              rect_y2):
    """Check if a line segment intersects with a rectangle"""
    # Check if line endpoints are inside rectangle
    if (rect_x1 <= x1 <= rect_x2 and rect_y1 <= y1 <= rect_y2) or \
       (rect_x1 <= x2 <= rect_x2 and rect_y1 <= y2 <= rect_y2):
        return True

    # Check intersection with each edge of rectangle
    def line_intersect(p1, p2, p3, p4):
        """Check if two line segments intersect"""

        def ccw(A, B, C):
            return (C[1] - A[1]) * (B[0] - A[0]) > (B[1] - A[1]) * (C[0] -
                                                                    A[0])

        return ccw(p1, p3, p4) != ccw(p2, p3, p4) and ccw(p1, p2, p3) != ccw(
            p1, p2, p4)

    # Rectangle edges
    edges = [
        ((rect_x1, rect_y1), (rect_x2, rect_y1)),  # top
        ((rect_x2, rect_y1), (rect_x2, rect_y2)),  # right
        ((rect_x2, rect_y2), (rect_x1, rect_y2)),  # bottom
        ((rect_x1, rect_y2), (rect_x1, rect_y1))  # left
    ]

    line_seg = ((x1, y1), (x2, y2))
    for edge in edges:
        if line_intersect(line_seg[0], line_seg[1], edge[0], edge[1]):
            return True
    return False


def detect_clusters(box_positions, cluster_distance=80):
    """Detect clusters of nearby bounding boxes"""
    clusters = []
    assigned = [False] * len(box_positions)

    for i, box1 in enumerate(box_positions):
        if assigned[i]:
            continue

        # Start new cluster
        cluster = [i]
        assigned[i] = True

        # Find all boxes within cluster distance
        cx1 = (box1[0] + box1[2]) / 2
        cy1 = (box1[1] + box1[3]) / 2

        for j, box2 in enumerate(box_positions):
            if assigned[j] or i == j:
                continue

            cx2 = (box2[0] + box2[2]) / 2
            cy2 = (box2[1] + box2[3]) / 2

            distance = math.sqrt((cx1 - cx2)**2 + (cy1 - cy2)**2)
            if distance < cluster_distance:
                cluster.append(j)
                assigned[j] = True

        if len(cluster) > 1:  # Only keep clusters with multiple boxes
            clusters.append(cluster)

    return clusters


def get_cluster_boundary(cluster_indices, box_positions):
    """Get the bounding rectangle of a cluster"""
    min_x = min(box_positions[i][0] for i in cluster_indices)
    min_y = min(box_positions[i][1] for i in cluster_indices)
    max_x = max(box_positions[i][2] for i in cluster_indices)
    max_y = max(box_positions[i][3] for i in cluster_indices)
    return (min_x, min_y, max_x, max_y)


def find_smart_label_position(box_center, current_box, current_box_idx,
                              all_boxes, all_labels, img_width, img_height,
                              label_text, font, clusters):
    """Find optimal position for label to avoid overlaps with cluster-aware algorithm"""
    cx, cy = box_center

    # Check if this box is in a cluster
    in_cluster = False
    cluster_boundary = None
    for cluster in clusters:
        if current_box_idx in cluster:
            in_cluster = True
            cluster_boundary = get_cluster_boundary(cluster, all_boxes)
            break

    # Determine distances to try based on clustering
    if in_cluster:
        # For clustered boxes, start with larger distances
        distances = [80, 120, 160, 200, 250, 300]
    else:
        # For isolated boxes, can use smaller distances
        distances = [40, 60, 80, 120, 160]

    # More angles for better coverage
    angles = [i * 15 for i in range(24)]  # 24 directions

    best_pos = None
    min_penalty = float('inf')

    for distance in distances:
        for angle in angles:
            # Calculate potential label position
            rad = math.radians(angle)
            lx = cx + distance * math.cos(rad)
            ly = cy + distance * math.sin(rad)

            # Keep label within image bounds with margin
            margin = 30
            lx = max(margin, min(lx, img_width - margin))
            ly = max(margin, min(ly, img_height - margin))

            # Calculate label bounds at this position
            label_bounds = calculate_label_bounds(lx, ly, label_text, font)

            # Calculate penalty for this position
            penalty = 0

            # 1. CRITICAL: Penalty for connecting line intersecting other boxes
            for i, box in enumerate(all_boxes):
                if i == current_box_idx:  # Skip the current box
                    continue

                bx1, by1, bx2, by2 = box

                # Check if connecting line intersects this box
                if line_intersects_rectangle(cx, cy, lx, ly, bx1, by1, bx2,
                                             by2):
                    penalty += 2000  # VERY HIGH penalty for line intersection

                # Check if label center is inside box
                if point_in_rectangle(lx, ly, box):
                    penalty += 1500  # Very high penalty for center inside box

                # Check if label circle overlaps with box
                label_rect = [
                    label_bounds['x1'], label_bounds['y1'], label_bounds['x2'],
                    label_bounds['y2']
                ]
                box_rect = {'x1': bx1, 'y1': by1, 'x2': bx2, 'y2': by2}

                if rectangles_overlap(
                    {
                        'x1': label_rect[0],
                        'y1': label_rect[1],
                        'x2': label_rect[2],
                        'y2': label_rect[3]
                    }, box_rect):
                    box_area = (bx2 - bx1) * (by2 - by1)
                    penalty += min(800, box_area / 50)

            # 2. Penalty for being too close to other labels
            for other_label_pos in all_labels:
                if other_label_pos:
                    ox, oy = other_label_pos
                    other_label_bounds = calculate_label_bounds(
                        ox, oy, "1", font)

                    distance_between = math.sqrt((lx - ox)**2 + (ly - oy)**2)
                    min_distance = label_bounds['radius'] + other_label_bounds[
                        'radius'] + 15

                    if distance_between < min_distance:
                        penalty += (min_distance - distance_between) * 15

            # 3. For clustered boxes, prefer positions away from cluster center
            if in_cluster and cluster_boundary:
                cluster_cx = (cluster_boundary[0] + cluster_boundary[2]) / 2
                cluster_cy = (cluster_boundary[1] + cluster_boundary[3]) / 2

                # Prefer directions that move away from cluster center
                to_cluster_center = math.sqrt((cluster_cx - cx)**2 +
                                              (cluster_cy - cy)**2)
                to_label_from_cluster = math.sqrt((cluster_cx - lx)**2 +
                                                  (cluster_cy - ly)**2)

                if to_label_from_cluster < to_cluster_center:
                    penalty += 300  # Penalty for moving toward cluster center
                else:
                    penalty -= 50  # Bonus for moving away from cluster

            # 4. Distance penalty (but much lower weight for clustered boxes)
            actual_distance = math.sqrt((lx - cx)**2 + (ly - cy)**2)
            if in_cluster:
                penalty += actual_distance * 0.02  # Very low weight for clustered boxes
            else:
                penalty += actual_distance * 0.1  # Normal weight for isolated boxes

            # 5. Edge penalties
            edge_margin = 40
            if lx < edge_margin:
                penalty += (edge_margin - lx) * 3
            if lx > img_width - edge_margin:
                penalty += (lx - (img_width - edge_margin)) * 3
            if ly < edge_margin:
                penalty += (edge_margin - ly) * 3
            if ly > img_height - edge_margin:
                penalty += (ly - (img_height - edge_margin)) * 3

            # 6. Directional preferences for clusters
            if in_cluster and cluster_boundary:
                # Prefer outward directions from cluster edges
                cluster_left = cluster_boundary[0]
                cluster_right = cluster_boundary[2]
                cluster_top = cluster_boundary[1]
                cluster_bottom = cluster_boundary[3]

                # If box is on left edge of cluster, prefer left placement
                if cx - cluster_left < 20 and lx < cx:
                    penalty -= 100
                # If box is on right edge of cluster, prefer right placement
                elif cluster_right - cx < 20 and lx > cx:
                    penalty -= 100
                # If box is on top edge of cluster, prefer top placement
                elif cy - cluster_top < 20 and ly < cy:
                    penalty -= 100
                # If box is on bottom edge of cluster, prefer bottom placement
                elif cluster_bottom - cy < 20 and ly > cy:
                    penalty -= 100

            if penalty < min_penalty:
                min_penalty = penalty
                best_pos = (lx, ly)

    # Enhanced fallback strategy for difficult cases
    if best_pos is None or min_penalty > 1000:
        # Try image corners with very large distances
        fallback_positions = [
            (60, 60),  # Top-left
            (img_width - 60, 60),  # Top-right
            (60, img_height - 60),  # Bottom-left
            (img_width - 60, img_height - 60),  # Bottom-right
            (img_width // 2, 60),  # Top-center
            (img_width // 2, img_height - 60),  # Bottom-center
            (60, img_height // 2),  # Left-center
            (img_width - 60, img_height // 2),  # Right-center
        ]

        for fallback_pos in fallback_positions:
            lx, ly = fallback_pos

            # Check if this position has line intersections
            has_intersection = False
            for i, box in enumerate(all_boxes):
                if i == current_box_idx:
                    continue
                if line_intersects_rectangle(cx, cy, lx, ly, box[0], box[1],
                                             box[2], box[3]):
                    has_intersection = True
                    break

            if not has_intersection:
                # Check conflicts with existing labels
                conflicts = False
                for other_label_pos in all_labels:
                    if other_label_pos:
                        ox, oy = other_label_pos
                        if math.sqrt((lx - ox)**2 + (ly - oy)**2) < 60:
                            conflicts = True
                            break

                if not conflicts:
                    best_pos = fallback_pos
                    break

    return best_pos if best_pos else (cx + 100, cy - 100)  # Final fallback


def optimize_all_label_positions(box_positions, img_width, img_height, font):
    """Optimize label positions for all boxes using a cluster-aware multi-pass approach"""
    num_boxes = len(box_positions)
    label_positions = [None] * num_boxes

    # Detect clusters of nearby boxes
    clusters = detect_clusters(box_positions)

    # Sort boxes by constraint priority:
    # 1. Boxes in clusters (most constrained)
    # 2. Smaller boxes (more constrained)
    def box_priority(idx):
        x1, y1, x2, y2 = box_positions[idx]
        area = (x2 - x1) * (y2 - y1)

        # Check if box is in a cluster
        in_cluster = any(idx in cluster for cluster in clusters)

        # Prioritize clustered boxes, then by area
        if in_cluster:
            return (0, area)  # Clustered boxes first, then by area
        else:
            return (1, area)  # Non-clustered boxes second, then by area

    box_indices_by_priority = sorted(range(num_boxes), key=box_priority)

    # Place labels in order of constraint (most constrained first)
    for idx in box_indices_by_priority:
        x1, y1, x2, y2 = box_positions[idx]
        cx = (x1 + x2) // 2
        cy = (y1 + y2) // 2

        label_text = str(idx + 1)

        # Find position considering all already placed labels and clusters
        label_pos = find_smart_label_position(
            (cx, cy), box_positions[idx], idx, box_positions, label_positions,
            img_width, img_height, label_text, font, clusters)
        label_positions[idx] = label_pos

    return label_positions


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_prompts', methods=['GET'])
def get_prompts():
    """Return available system prompts"""
    return jsonify(SYSTEM_PROMPTS)


@app.route('/detect', methods=['POST'])
def detect_bounding_boxes():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400

        image_file = request.files['image']
        custom_prompt = request.form.get('custom_prompt', '')
        system_prompt = request.form.get('system_prompt',
                                         DEFAULT_SYSTEM_PROMPT)
        num_calls = int(request.form.get('num_calls', 1))
        model_name = request.form.get('model', 'gemini-2.0-flash-exp')

        image = Image.open(image_file.stream)

        if image.mode != 'RGB':
            image = image.convert('RGB')

        # Configure generation config with the new SDK
        config = GenerateContentConfig(
            system_instruction=system_prompt,
            temperature=0.5,
            safety_settings=[
                SafetySetting(
                    category=HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                    threshold=HarmBlockThreshold.BLOCK_ONLY_HIGH,
                ),
            ],
            response_mime_type="application/json",
            response_schema=list[BoundingBox],
        )

        # Save image to bytes for Part.from_bytes
        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_bytes = img_byte_arr.getvalue()

        results = []
        for i in range(num_calls):
            # Create content parts with the new SDK format
            contents = [
                Part.from_bytes(data=img_bytes, mime_type="image/png"),
                custom_prompt
            ]

            response = client.models.generate_content(model=model_name,
                                                      contents=contents,
                                                      config=config)

            try:
                text_response = response.text.strip()
                if text_response.startswith('```json'):
                    text_response = text_response[7:]
                if text_response.endswith('```'):
                    text_response = text_response[:-3]

                bounding_boxes = json.loads(text_response)

                if not isinstance(bounding_boxes, list):
                    bounding_boxes = [bounding_boxes]

                results.append({
                    'call_number': i + 1,
                    'bounding_boxes': bounding_boxes,
                    'raw_response': response.text
                })
            except json.JSONDecodeError as e:
                results.append({
                    'call_number': i + 1,
                    'error': f'Failed to parse JSON: {str(e)}',
                    'raw_response': response.text
                })

        # Reuse the image bytes we already have
        image_base64 = base64.b64encode(img_bytes).decode()

        return jsonify({
            'results': results,
            'original_image': f'data:image/png;base64,{image_base64}',
            'image_dimensions': {
                'width': image.width,
                'height': image.height
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/visualize', methods=['POST'])
def visualize_bounding_boxes():
    """
    Plots bounding boxes on an image with smart label placement and better colors.
    """
    try:
        data = request.get_json()
        image_data = data['image'].split(',')[1]
        bounding_boxes = data['bounding_boxes']

        image = Image.open(io.BytesIO(base64.b64decode(image_data)))
        width, height = image.size
        draw = ImageDraw.Draw(image)

        # Try to load font
        try:
            font = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 14)
        except:
            try:
                font = ImageFont.truetype("arial.ttf", 14)
            except:
                font = None

        # Process all boxes first to collect positions
        box_positions = []
        for i, bbox in enumerate(bounding_boxes):
            if 'box_2d' in bbox:
                # Scale normalized coordinates to image dimensions
                abs_y_min = int(bbox['box_2d'][0] / 1000 * height)
                abs_x_min = int(bbox['box_2d'][1] / 1000 * width)
                abs_y_max = int(bbox['box_2d'][2] / 1000 * height)
                abs_x_max = int(bbox['box_2d'][3] / 1000 * width)
                box_positions.append(
                    (abs_x_min, abs_y_min, abs_x_max, abs_y_max))

        # Optimize all label positions using the full algorithm
        label_positions = optimize_all_label_positions(box_positions, width,
                                                       height, font)

        # Now draw everything
        for i, (bbox, box_pos, label_pos) in enumerate(
                zip(bounding_boxes, box_positions, label_positions)):
            if 'box_2d' in bbox:
                # Use better colors
                color = BBOX_COLORS[i % len(BBOX_COLORS)]
                rgb_color = hex_to_rgb(color)

                x1, y1, x2, y2 = box_pos
                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2

                # Draw the rectangle
                draw.rectangle(
                    ((x1, y1), (x2, y2)),
                    outline=rgb_color,
                    width=3,
                )

                # Draw numbered label with connecting line
                label = str(i + 1)
                lx, ly = label_pos

                # Draw thin connecting line from label to center
                draw.line([(lx, ly), (cx, cy)], fill=rgb_color, width=1)

                # Calculate appropriate radius for label circle
                label_bounds = calculate_label_bounds(lx, ly, label, font)
                radius = label_bounds['radius']

                # Draw label background circle
                draw.ellipse(
                    [lx - radius, ly - radius, lx + radius, ly + radius],
                    fill=rgb_color,
                    outline='white',
                    width=2)

                # Draw label text
                if font:
                    bbox_text = font.getbbox(label)
                    text_width = bbox_text[2] - bbox_text[0]
                    text_height = bbox_text[3] - bbox_text[1]
                else:
                    text_width = len(label) * 8
                    text_height = 12

                draw.text((lx - text_width // 2, ly - text_height // 2),
                          label,
                          fill='white',
                          font=font)

                # Don't draw the object label on the image to avoid clutter

        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)
        image_base64 = base64.b64encode(img_byte_arr.getvalue()).decode()

        return jsonify(
            {'visualized_image': f'data:image/png;base64,{image_base64}'})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
