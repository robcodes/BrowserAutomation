let uploadedImage = null;
let systemPrompts = {};

document.getElementById('imageInput').addEventListener('change', handleImageUpload);
document.getElementById('detectButton').addEventListener('click', detectBoundingBoxes);
document.getElementById('promptSelect').addEventListener('change', handlePromptSelection);

// Load available prompts on page load
loadSystemPrompts();

function handleImageUpload(event) {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function(e) {
            uploadedImage = file;
            document.getElementById('imagePreview').innerHTML = 
                `<img src="${e.target.result}" alt="Uploaded image">`;
        };
        reader.readAsDataURL(file);
    }
}

async function detectBoundingBoxes() {
    if (!uploadedImage) {
        alert('Please upload an image first');
        return;
    }

    const detectButton = document.getElementById('detectButton');
    const loading = document.getElementById('loading');
    const results = document.getElementById('results');
    
    detectButton.disabled = true;
    loading.style.display = 'block';
    results.style.display = 'none';

    const formData = new FormData();
    formData.append('image', uploadedImage);
    formData.append('custom_prompt', document.getElementById('customPrompt').value);
    formData.append('system_prompt', document.getElementById('systemPrompt').value);
    formData.append('num_calls', document.getElementById('numCalls').value);
    formData.append('model', document.getElementById('modelSelect').value);

    try {
        const response = await fetch('/detect', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        
        if (response.ok) {
            displayResults(data);
        } else {
            alert('Error: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error: ' + error.message);
    } finally {
        detectButton.disabled = false;
        loading.style.display = 'none';
    }
}

function displayResults(data) {
    const results = document.getElementById('results');
    const resultsContainer = document.getElementById('resultsContainer');
    
    results.style.display = 'block';
    resultsContainer.innerHTML = '';

    data.results.forEach(result => {
        const resultDiv = document.createElement('div');
        resultDiv.className = 'result-item';
        
        let content = `
            <div class="result-header">
                <h3>API Call ${result.call_number}</h3>
                <button class="toggle-raw" onclick="toggleRawResponse(${result.call_number})">
                    Toggle Raw Response
                </button>
            </div>
        `;

        if (result.error) {
            content += `<div class="error">${result.error}</div>`;
        } else if (result.bounding_boxes && result.bounding_boxes.length > 0) {
            content += '<div class="bbox-list">';
            content += '<h4>Detected Objects:</h4>';
            result.bounding_boxes.forEach((bbox, idx) => {
                if (bbox.box_2d) {
                    const [y_min, x_min, y_max, x_max] = bbox.box_2d;
                    content += `
                        <div class="bbox-item">
                            ${idx + 1}. <strong>${bbox.label}</strong> - 
                            [y_min: ${y_min}, x_min: ${x_min}, y_max: ${y_max}, x_max: ${x_max}]
                        </div>
                    `;
                } else {
                    // Fallback for old format
                    content += `
                        <div class="bbox-item">
                            ${idx + 1}. <strong>${bbox.object || bbox.label}</strong> - 
                            [xmin: ${bbox.xmin}, ymin: ${bbox.ymin}, xmax: ${bbox.xmax}, ymax: ${bbox.ymax}]
                        </div>
                    `;
                }
            });
            content += '</div>';
            
            content += `<div id="viz-${result.call_number}" class="visualized-image"></div>`;
        } else {
            content += '<p>No bounding boxes detected</p>';
        }

        content += `
            <div id="raw-${result.call_number}" class="raw-response" style="display: none;">
                ${escapeHtml(result.raw_response)}
            </div>
        `;

        resultDiv.innerHTML = content;
        resultsContainer.appendChild(resultDiv);

        if (result.bounding_boxes && result.bounding_boxes.length > 0) {
            visualizeBoundingBoxes(data.original_image, result.bounding_boxes, result.call_number, data.image_dimensions);
        }
    });
}

async function visualizeBoundingBoxes(originalImage, boundingBoxes, callNumber, imageDimensions) {
    try {
        const response = await fetch('/visualize', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                image: originalImage,
                bounding_boxes: boundingBoxes,
                image_dimensions: imageDimensions
            })
        });

        const data = await response.json();
        
        if (response.ok) {
            document.getElementById(`viz-${callNumber}`).innerHTML = 
                `<img src="${data.visualized_image}" alt="Visualized bounding boxes">`;
        }
    } catch (error) {
        console.error('Error visualizing bounding boxes:', error);
    }
}

function toggleRawResponse(callNumber) {
    const rawDiv = document.getElementById(`raw-${callNumber}`);
    rawDiv.style.display = rawDiv.style.display === 'none' ? 'block' : 'none';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function loadSystemPrompts() {
    try {
        const response = await fetch('/get_prompts');
        systemPrompts = await response.json();
    } catch (error) {
        console.error('Error loading system prompts:', error);
    }
}

function handlePromptSelection(event) {
    const selectedPrompt = event.target.value;
    const systemPromptTextarea = document.getElementById('systemPrompt');
    
    if (selectedPrompt && systemPrompts[selectedPrompt]) {
        systemPromptTextarea.value = systemPrompts[selectedPrompt];
    }
}